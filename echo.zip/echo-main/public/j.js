document.addEventListener('DOMContentLoaded', function () {
    const todayEntryText = document.getElementById('todayEntry');
    const previousEntries = document.getElementById('previousEntries');
    const saveButton = document.getElementById('saveButton');
    const daysContainer = document.getElementById('days');
    const monthDisplay = document.getElementById('month');

    let entries = [];
    let selectedDate = null;
    let currentMonth = new Date().getMonth();
    let currentYear = new Date().getFullYear();
    const monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

    const userId = localStorage.getItem('userId');

    // Function to display the calendar
    function displayCalendar() {
        monthDisplay.textContent = `${monthNames[currentMonth]} ${currentYear}`;
        daysContainer.innerHTML = ''; // Clear previous days

        const firstDay = new Date(currentYear, currentMonth, 1).getDay(); // Get the first day of the month (0 = Sunday, 1 = Monday, ...)
        const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate(); // Get the number of days in the month

        // Create empty cells for days before the first day
        for (let i = 0; i < firstDay; i++) {
            const emptyElement = document.createElement('div');
            daysContainer.appendChild(emptyElement); // Add empty cells for alignment
        }

        // Fill the calendar with days
        for (let i = 1; i <= daysInMonth; i++) {
            const dayElement = document.createElement('div');
            dayElement.textContent = i;
            dayElement.className = 'day'; // Add a class for styling
            daysContainer.appendChild(dayElement);
        }
    }

    // Function to display previous entries
    function displayPreviousEntries() {
        previousEntries.innerHTML = '<h3>Previous Entries</h3>';
        entries.forEach(entry => {
            const entryElement = document.createElement('li');
            entryElement.textContent = `${entry.date}: ${entry.text}`;
            previousEntries.appendChild(entryElement);
        });
    }

     // Function to fetch previous entries from the database
     function fetchEntries() {
        const startDate = `${currentYear}-${currentMonth + 1}-01`;
        const endDate = `${currentYear}-${currentMonth + 1}-${new Date(currentYear, currentMonth + 1, 0).getDate()}`;
        
        fetch(`/entries?user_id=${userId}&start_date=${startDate}&end_date=${endDate}`)
            .then(response => response.json())
            .then(data => {
                entries = data;
                displayPreviousEntries();
            })
            .catch(error => console.error('Error fetching entries:', error));
    }

   // Event listener for Save Button
   saveButton.addEventListener('click', async function () {
    const entryText = todayEntryText.value;

    if (entryText && selectedDate) {
        const entryDate = `${currentYear}-${currentMonth + 1}-${selectedDate.split(' ')[0]}`; // Format the date for database
        try {
            const response = await fetch('/save-entry', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    user_id: userId, // User ID from local storage
                    entry_date: entryDate, // Entry date formatted for database
                    entry_text: entryText // Entry text
                }),
            });

            const data = await response.json(); // Parse the JSON response

            if (response.ok) {
                alert(data.message); // Show success message
                entries.push({ date: selectedDate, text: entryText }); // Add entry to local entries array
                displayPreviousEntries(); // Update the displayed entries
                todayEntryText.value = ''; // Clear text area
                selectedDate = null; // Clear selected date after saving
            } else {
                alert(data.message || 'An error occurred. Please try again.'); // Show error message
            }
        } catch (error) {
            console.error('Error:', error);
            alert('An unexpected error occurred. Please try again.');
        }
    } else {
        alert('Please select a date and enter text for the journal entry.');
    }
});

    // Event listener for selecting a date
    daysContainer.addEventListener('click', function (e) {
        if (e.target.classList.contains('day')) {
            const day = e.target.innerText;
            selectedDate = `${day} ${monthNames[currentMonth]} ${currentYear}`;
            alert(`Selected Date: ${selectedDate}`);
        }
    });

    // Functions for navigating months
    document.getElementById('prev').addEventListener('click', function () {
        currentMonth--;
        if (currentMonth < 0) {
            currentMonth = 11;
            currentYear--;
        }
        displayCalendar();
    });

    document.getElementById('next').addEventListener('click', function () {
        currentMonth++;
        if (currentMonth > 11) {
            currentMonth = 0;
            currentYear++;
        }
        displayCalendar();
    });

    // Initial calendar display
    displayCalendar();
});





