document.getElementById('registration-form').addEventListener('submit', function (event) {
    event.preventDefault();

    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`,
    })
    .then(response => {
        if (response.ok) {
            return response.text();
        } else {
            throw new Error('Registration failed');
        }
    })
    .then(message => {
        document.getElementById('success-message').innerText = message;
        document.getElementById('success-message').style.display = 'block';
        document.getElementById('registration-form').reset();
    })
    .catch(error => {
        document.getElementById('error-message').innerText = error.message;
    });
});
