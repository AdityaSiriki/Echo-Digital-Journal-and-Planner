// Enable marking/unmarking grid cells on click
document.querySelectorAll('.grid-cell').forEach(cell => {
    cell.addEventListener('click', () => {
      cell.classList.toggle('marked');
    });
  });
  // Back button functionality
function goBack() {
    window.history.back();
}
const yearSelect = document.getElementById('yearSelect');
const currentYear = new Date().getFullYear();
for (let year = currentYear; year <= currentYear + 10; year++) {
    const option = document.createElement('option');
    option.value = year;
    option.textContent = year;
    yearSelect.appendChild(option);
}

// Optional: Handle selection change
const monthSelect = document.getElementById('monthSelect');
monthSelect.addEventListener('change', () => {
    const selectedMonth = monthSelect.value;
    const selectedYear = yearSelect.value;

    if (selectedMonth && selectedYear) {
        console.log(`Selected: ${monthSelect.options[selectedMonth].text} ${selectedYear}`);
    }
});

yearSelect.addEventListener('change', () => {
    const selectedMonth = monthSelect.value;
    const selectedYear = yearSelect.value;

    if (selectedMonth && selectedYear) {
        console.log(`Selected: ${monthSelect.options[selectedMonth].text} ${selectedYear}`);
    }
});


