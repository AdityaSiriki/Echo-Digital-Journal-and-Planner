function scrollToNextSection() {
    // You can add functionality here to scroll to the next section when the arrow is clicked.
    // Currently, this function doesn't do anything but can be expanded.
    console.log('Arrow clicked!');
}

