// Wait for the DOM to load
document.addEventListener("DOMContentLoaded", function() {

    // Form validation and submission handling
    const form = document.getElementById("loginForm");
    const emailInput = document.getElementById("email");
    const passwordInput = document.getElementById("password");
    const emailError = document.getElementById("email-error");
    const passwordError = document.getElementById("password-error");

    form.addEventListener("submit", function(event) {
        event.preventDefault(); // Prevent form submission

        const emailValue = emailInput.value.trim();
        const passwordValue = passwordInput.value.trim();

        // Basic validation for email and password
        if (!validateEmail(emailValue)) {
            emailError.textContent = "Please enter a valid email address (e.g., user@gmail.com).";
            return;
        } else {
            emailError.textContent = "";
        }

        if (passwordValue === "") {
            passwordError.textContent = "Please enter your password.";
            return;
        } else {
            passwordError.textContent = "";
        }

        // Simulating successful login after validation
        if (validateCredentials(emailValue, passwordValue)) {
            // In a real application, you would redirect the user to the next page
            window.location.href = "dashboard.html"; // Simulated redirection
        } else {
            passwordError.textContent = "Invalid login credentials. Please try again.";
        }
    });

    // Dummy function to simulate login credential validation
    function validateCredentials(email, password) {
        // Simple condition to simulate valid login (you can replace with real validation logic)
        return email === "user@example.com" && password === "password123";
    }

    // Example email validation using regular expression
    function validateEmail(email) {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
    }
});
