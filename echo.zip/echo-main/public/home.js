function navigate(page) {
    alert(`Navigating to ${page} page`);
    // Implement navigation logic here
}

function goNext() {
    window.history.forward();
}

function navigate(page) {
    window.location.href = `/${page}`;
}
